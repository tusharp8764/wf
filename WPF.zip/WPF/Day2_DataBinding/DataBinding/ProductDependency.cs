﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;
namespace DataBinding
{
    class ProductDependency:INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string productname;
        public string ProductName
        {
            get { return productname; }
            set { productname = value;
            RaiseEvent("ProductName");
            
            }
        
        
        }
        private string category;
        public string Category
        {
            get { return category; }
            set
            {
                category = value;
                RaiseEvent("Category");

            }


        }

        private void RaiseEvent(string propName)
        {
            if (PropertyChanged != null)
            { 
            PropertyChanged(this,new PropertyChangedEventArgs(propName));
            }
        }

    }
}
