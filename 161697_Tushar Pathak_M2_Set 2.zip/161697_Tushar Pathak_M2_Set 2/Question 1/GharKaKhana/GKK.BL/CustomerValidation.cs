﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GKK.Entity;
using GKK.DAL;
using GKK.Exception;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace GKK.BL
{
    /// <summary>
    /// Employee ID : 161697
    /// Employee Name : Tushar Pathak
    /// Description : This class is for validation of student class
    /// Date of Creation : October 17th 2018
    /// </summary>

    public class CustomerValidation
    {
        CustomerOperations custOpr;
        public DataTable GetCustomer_BLL()
        {
            DataTable dtcust;
            try
            {
                custOpr = new CustomerOperations();
                dtcust = custOpr.GetCustomer_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dtcust;
        }

        public bool validateEmp(Customer newCust)
        {
            bool isValidcust = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newCust.CustdName == string.Empty)
                {
                    isValidcust = false;
                    sbError.Append("Please enter Customer Name");
                }
                else if (!Regex.IsMatch(newCust.CustdName, "[A-Z][a-z]+"))
                {
                    isValidcust = false;
                    sbError.Append("customer name should have alphabets only\n");
                }

                //Checking Customer Pincode that it should be 6 digits
                if (newCust.Pincode < 100000 || newCust.Pincode > 999999)
                {
                    sbError.Append("Student ID should be 6 digits long\n");
                    isValidcust = false;
                }

                

                if (!isValidcust) throw new CustomerException(sbError.ToString());
            }
            catch (CustomerException ex)
            { throw ex; }

            return isValidcust;
        }

        //Validation class for inserting a Customer 

        public int AddCustomer_BLL(Customer newCust)
        {
            int rowsAffected = 0;
            CustomerOperations operationObj;
            try
            {
                if (validateEmp(newCust))
                {
                    operationObj = new CustomerOperations();
                    rowsAffected = operationObj.AddCustomer_DAL(newCust);
                }
            }
            catch (CustomerException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }

    }
}
